/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package area.of.geometric.shapes;


 class Opertion {
     String nameshapes;
     Shape allAreas[];
    Opertion(String nameshapes,Shape Areas[]){
        this.nameshapes=nameshapes;
        this.allAreas=Areas;
        
    } 
    public Shape[]getAreas(){
        return allAreas;
    }
    }

class Shape{
    String nameshapes;
    double length;
    double width;
    Shape(String nameshapes,double length,double width){
        this.nameshapes=nameshapes;
        this.length=length;
        this.width=width;
    }
}

    

    
    

